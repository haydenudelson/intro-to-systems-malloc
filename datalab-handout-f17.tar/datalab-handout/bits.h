/* Bit manipulations */
int bitNor(int, int);
int test_bitNor(int, int);
int allEvenBits();
int test_allEvenBits();
int copyLSB(int);
int test_copyLSB(int);
int bitMask(int, int);
int test_bitMask(int, int);
int isPower2(int);
int test_isPower2(int);
int logicalNeg(int);
int test_logicalNeg(int);
/* Two's complement arithmetic */
int isTmax(int);
int test_isTmax(int);
int fitsBits(int, int);
int test_fitsBits(int, int);
int isLess(int, int);
int test_isLess(int, int);
int absVal(int);
int test_absVal(int);
int isNonZero(int);
int test_isNonZero(int);
/* FP operations */
unsigned float_abs(unsigned);
unsigned test_float_abs(unsigned);
unsigned float_neg(unsigned);
unsigned test_float_neg(unsigned);
unsigned float_i2f(int);
unsigned test_float_i2f(int);
